﻿using System;
namespace Keaz.Models
{
    public class Compte
    {
        public string type_compte { get; set; }
        public string numero_compte { get; set; }
        public string montant { get; set; }
        public string type_operation { get; set; }

    }


}
