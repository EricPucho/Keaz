﻿using System;
namespace Keaz.Models
{
    public class MenuOperations
    {
        public string text { get; set; }
        public string icon { get; set; }
    }
}