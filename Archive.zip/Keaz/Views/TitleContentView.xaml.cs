﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace Keaz.Views
{
    public partial class TitleContentView : ContentView
    {
        public TitleContentView()
        {
            InitializeComponent();
        }
    }
}
