﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Keaz.Views
{
    public partial class CartesPage : ContentPage
    {
        public CartesPage()
        {
            InitializeComponent();
        }
    }
}
