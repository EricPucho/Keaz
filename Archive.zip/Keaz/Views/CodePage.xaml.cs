﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Keaz.Views
{
    public partial class CodePage : ContentPage
    {
        public CodePage()
        {
            InitializeComponent();
        }
    }
}
