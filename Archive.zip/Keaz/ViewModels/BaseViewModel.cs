﻿using Keaz.Helpers;

namespace Keaz.ViewModels
{
    public class BaseViewModel : ObservableObject
    {
        public BaseViewModel()
        {

        }

    }
}
